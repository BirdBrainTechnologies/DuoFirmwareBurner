#!/bin/bash
java -jar ./HummingbirdFirmwareBurner.jar
